<nav class="col-md-2 d-none d-md-block bg-light sidebar">
  <div class="sidebar-sticky">
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link active" href="#">
          Dashboard
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">
          Personal Details
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">
          Rent Payment
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">
          Reports/ Records
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">
          Contact Management
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">
          Vacate Room
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">
          Contact Us
        </a>
      </li>
    </ul>
  </div>
</nav>
