<footer class="main-footer">
    <strong>Copyright &copy; <?php
        $year = date("Y");
        echo $year;
          ?> <a href="#">januh254@gmail.com</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Call <a href="#">0714200992</a></b>
    </div>
  </footer>
